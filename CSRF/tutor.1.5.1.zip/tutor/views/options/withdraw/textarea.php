

<textarea name="tutor_withdraw_options[<?php echo $method_id; ?>][<?php echo $field_name; ?>]"><?php echo $saved_value; ?></textarea>