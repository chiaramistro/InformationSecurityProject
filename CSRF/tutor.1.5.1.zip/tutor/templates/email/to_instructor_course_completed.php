<?php
/**
 * @package TutorLMS/Templates
 * @version 1.4.3
 */

?>

<p> Dear {instructor_username}, </p>

<p>
	Mr. {student_username} has recently completed <strong>{course_name}</strong> at <strong>{completion_time}</strong>. The completed course URL is: <strong>{course_url}</strong>.
</p>