<?php
/**
 * Course Loop End
 *
 * @package TutorLMS/Templates
 * @version 1.4.3
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="<?php tutor_course_loop_col_classes(); ?>">
<div class="<?php tutor_course_loop_wrap_classes(); ?>">
