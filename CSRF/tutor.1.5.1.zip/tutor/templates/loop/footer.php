<?php
/**
 * @package TutorLMS/Templates
 * @version 1.4.3
 */

?>

<div class="tutor-loop-course-footer">
    <?php  tutor_course_loop_price(); ?>
</div>
